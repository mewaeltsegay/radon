create definer = root@localhost trigger before_insert_inventory
    before insert
    on inventory
    for each row
BEGIN
  IF new.unique_id IS NULL THEN
    SET new.unique_id = uuid();
  END IF;
END;

